package com.lbs.background_android_service.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.net.wifi.WifiManager
import android.os.IBinder
import android.text.format.Formatter
import android.util.Log
import androidx.core.app.NotificationCompat
import com.lbs.background_android_service.lib.NanoHTTPD

class BackgroundApi: Service() {
    private val CHANNEL_ID = "ServiceBackgroundAPIChannel"
    private lateinit var httpServer: NanoHTTPD
    private val logTag = "BackgroundApi"
    private var httpServerPort = 8080

    private fun log (message:String) {
        Log.d(logTag, "$logTag : $message");
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        intent?.getIntExtra("port", 8080)?.let {
            httpServerPort = it
        }

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("API em execução")
            .setContentText("Seu servidor local está rodando em background")
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .build()

        startForeground(1, notification)

        try {
            if (!::httpServer.isInitialized || !httpServer.isAlive) {
                httpServer = NanoHTTPD(httpServerPort)
                httpServer.start()
                val wifiManager = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
                val ipAddress = Formatter.formatIpAddress(wifiManager.connectionInfo.ipAddress)

                log("Servidor rest: INICIADO em http://$ipAddress:$httpServerPort/swagger")
            } else {
                log("Servidor já está em execução na porta $httpServerPort")
            }
        } catch (e: Exception) {
            log("Servidor rest: Erro ao iniciar: ${e.message}")
        }

        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        if (::httpServer.isInitialized) {
            httpServer.stop()
            Log.d("BackgroundApi", "Servidor rest: PARADO")
        }
    }



    private fun createNotificationChannel() {
        val serviceChannel = NotificationChannel(
            CHANNEL_ID,
            "Canal da API em background",
            NotificationManager.IMPORTANCE_DEFAULT
        )
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(serviceChannel)
    }
}
