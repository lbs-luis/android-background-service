# android-background-service
uma poc visando explorar e testar serviços em segundo plano no android
